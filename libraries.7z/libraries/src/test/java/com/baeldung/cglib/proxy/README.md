### Relevant articles

- [Introduction to cglib](http://www.baeldung.com/cglib)
