package com.baeldung.serenity;

import net.serenitybdd.jbehave.SerenityStory;

public class GithubUserProfilePayloadIntegrationTest extends SerenityStory {

}
