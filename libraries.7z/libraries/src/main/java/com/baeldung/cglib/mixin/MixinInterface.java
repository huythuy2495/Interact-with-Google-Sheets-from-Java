package com.baeldung.cglib.mixin;

public interface MixinInterface extends Interface1, Interface2 {
}