package com.baeldung.cglib.mixin;

public interface Interface2 {
    String second();
}