package com.baeldung.cglib.mixin;

public interface Interface1 {
    String first();
}