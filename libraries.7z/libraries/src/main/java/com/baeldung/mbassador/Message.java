package com.baeldung.mbassador;

public class Message {

}
