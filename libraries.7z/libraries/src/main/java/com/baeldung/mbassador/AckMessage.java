package com.baeldung.mbassador;

public class AckMessage extends Message {

}
