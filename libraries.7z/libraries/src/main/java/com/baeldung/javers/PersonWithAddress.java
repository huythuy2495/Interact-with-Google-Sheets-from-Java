package com.baeldung.javers;


import java.util.List;

public class PersonWithAddress {
    private Integer id;
    private String name;
    private List<Address> address;

    public PersonWithAddress(Integer id, String name, List<Address> address) {
        this.id = id;
        this.name = name;
        this.address = address;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Address> getAddress() {
        return address;
    }

    public void setAddress(List<Address> address) {
        this.address = address;
    }
}
