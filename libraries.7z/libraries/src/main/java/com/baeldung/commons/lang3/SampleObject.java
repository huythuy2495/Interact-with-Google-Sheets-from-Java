package com.baeldung.commons.lang3;

public class SampleObject {
    
    //Ignored

}
