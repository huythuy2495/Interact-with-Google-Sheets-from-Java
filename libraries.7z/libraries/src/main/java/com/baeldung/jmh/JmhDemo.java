package com.baeldung.jmh;

import java.io.IOException;

import org.openjdk.jmh.Main;
import org.openjdk.jmh.runner.RunnerException;

public class JmhDemo {
    public static void main(String[] args) throws RunnerException, IOException {
        Main.main(args);
    }
}
