package com.baeldung.jmh.warmup.dummy;

public class Dummy {

    public void m() {

    }

}
