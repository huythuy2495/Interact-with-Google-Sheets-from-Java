package com.baeldung.jmh;

import org.openjdk.jmh.annotations.Benchmark;

public class BenchMark {

    @Benchmark
    public void init() {

    }

}
