package com.baeldung.bytebuddy;

public class Foo {

    public String sayHelloFoo() { return "Hello in Foo!"; }

}
