package com.baeldung.streamex;

public class Role {

}
