package com.baeldung.serenity.membership;

/**
 * @author aiet
 */
public enum  MemberGrade {

    Bronze, Silver, Gold;

}
